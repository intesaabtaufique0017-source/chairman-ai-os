# Production architecture

Android Chrome/PWA
    |
    v
Chairman API
    |
    v
CEO Orchestrator
    |
    +--> COO
    +--> Research Agent -> Search/Web
    +--> Fact Checker
    +--> Marketing
    +--> Finance
    +--> Script
    +--> Video/TTS
    +--> QC
    |
    v
Approval Queue
    |
    v
Chairman: APPROVE / REJECT
    |
    v
Publishing Connector

CEO autonomous decision rule:
- Low/normal/reversible -> CEO decides.
- High-impact/legal/reputation/large spend -> escalate.
- Final publication -> Chairman approval.
