# Android setup

This is the mobile-first Chairman dashboard prototype.

## Fastest way
1. Put `index.html` and `manifest.json` on any static web host.
2. Open the page in Chrome on Android.
3. Chrome menu -> Add to Home screen / Install app.
4. Use it as your Chairman dashboard.

## Important
This UI is the control surface. A real autonomous backend still needs:
- live web/search provider
- LLM provider
- persistent database
- scheduler/automation engine
- video/TTS renderer
- YouTube/Instagram/TikTok publishing connector
- secrets/API key storage

Those services cannot be safely embedded into a static Android page. Never put private API keys directly into `index.html`.

## Intended authority
Chairman: mission + final publish approval.
CEO: autonomous normal decisions.
COO: execution.
Departments: research, fact-check, marketing, finance, script, video, QC.
